import pygame as pg
from pygame.locals import *
import pygame.sprite as sprite
import os
import math
import random
import pathlib
from pttools import *
import pgtools as pgt


def get_font(game, fontname=None, fontsize=None, font=None):
    if font:
        return font
    if fontname:
        return pg.font.Font(name=fontname, size=fontsize)
    if fontsize:
        return pg.font.Font(size=fontsize)
    else:
        return game.font


class Label(pgt.SpriteObject):
    def __init__(self, game, pos=(0, 0), value="X", fontsize=50, font=None, anchor='tl', color="white",
                 tcolor=(0, 0, 0), var=None, str_format=None, visible=True):
        super().__init__(game=game, pos=pos, anchor=anchor, tcolor=tcolor, visible=visible)
        self.font = get_font(game, fontsize=fontsize, font=font)

        self.image = None
        self.str_format = str_format
        if not var: var = pgt.TraceVar(value)
        self._var = var
        self._var.trace_add(self.render, mode='c')
        self.color = color
        self.render()

    def render(self, *args):
        pos = pgt.get_rect_pos(self.rect, self.anchor)
        if self.str_format:
            txt = self.str_format.format(self.value)
        else:
            txt = str(self.value)
        self.image = pgt.create_text(text=txt, font=self.font, color=self.color)
        self.rect = self.image.get_rect()
        pgt.set_rect_pos(self.rect, pos, self.anchor)

    @property
    def var(self):
        return self._var

    @property
    def value(self):
        return self.var.value

    @value.setter
    def value(self, value):
        self.var.value = value


class Checkbox(pgt.SpriteObject):
    def __init__(self, game, pos=(0, 0), text="Checkbox", fontsize=50, font=None, anchor='tl',
                 color="white",  tcolor=(0, 0, 0), func=None, tag=None, checked=False, enabled=True, visible=True):
        super().__init__(game=game, pos=pos, anchor=anchor, tcolor=tcolor, visible=visible)
        self.font = get_font(game, fontsize=fontsize, font=font)
        self._enabled = enabled
        self._text = text
        self._checked = checked
        self._color = color
        self.tag = tag
        self.func = func
        self.activate_events()
        self.render()

    def render(self):
        pos = self.pos
        text = pgt.create_text(text=self._text, font=self.font, antialias=True, color=self._color)
        size = pgt.get_size(text)
        l = size.h - 4
        padding = 6
        size.w += l + padding + 10
        self.image = pg.Surface(size)
        self.rect = self.image.get_rect()
        self.set_pos(pos)

        # Box links
        pg.draw.rect(self.image, color=self._color, rect=(0, 0, l, l), width=3)

        if self._checked:
            pg.draw.line(self.image, color=self._color, start_pos=(padding, padding),
                         end_pos=(l-padding-1, l-padding-1), width=3)
            pg.draw.line(self.image, color=self._color, start_pos=(l-padding-1, padding),
                         end_pos=(padding, l-padding-1), width=3)

        # Text rechts
        text_rect = text.get_rect()
        text_rect.midleft = (l + 10, l//2)
        self.image.blit(text, dest=text_rect.topleft)

    def handle_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos) and self._enabled:
                self._checked = not self._checked
                self.render()
                if self.func:
                    self.func(self)

    @property
    def checked(self):
        return self._checked

    @checked.setter
    def checked(self, value):
        self._checked = value
        self.render()

    @property
    def text(self):
        return self._text

    @text.setter
    def text(self, value):
        self._text = value
        self.render()

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, value):
        self._enabled = value
        self.render()


class Button(pgt.SpriteObject):
    def __init__(self, game, pos=(0, 0), size=None, text="Button", fontsize=50, font=None, anchor='tl',
                 color="white", hot_color='blue', bg_color='darkblue', tcolor=(0, 0, 0), func=None, tag=None,
                 enabled=True, visible=True):
        self.font = get_font(game, fontsize=fontsize, font=font)
        txt = pgt.create_text(text=text, font=self.font, antialias=True, color=color)
        if not size:
            w, h = txt.get_size()
            w += 20
            h += 10
            size = (w, h)
        self.size = pgt.Size(size)
        super().__init__(game=game, pos=pos, size=size, anchor=anchor, tcolor=tcolor, active=enabled, visible=visible)
        self._text = text
        self.color = color
        self.tag = tag if tag else text
        self.bg_color = bg_color
        self.hot_color = hot_color
        self.hot = False
        self.func = func
        self.render()
        self.activate_events()

    def render(self):
        txt = pgt.create_text(text=self._text, font=self.font, antialias=True, color=self.color)
        self.image.fill(self.tcolor)
        if not self.enabled:
            col = 'darkgray'
        elif self.hot:
            col = self.hot_color
        else:
            col = self.bg_color
        pg.draw.rect(self.image, color=col, rect=(0, 0, self.size.w, self.size.h), border_radius=int(self.size.h // 4))
        text_rect = txt.get_rect()
        text_rect.center = self.image.get_rect().center
        self.image.blit(txt, dest=text_rect.topleft)

    def handle_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos) and self.enabled:
                if self.func:
                    self.func(self)

        if event.type == pg.MOUSEMOTION:
            if self.rect.collidepoint(event.pos):
                if not self.hot:
                    self.hot = True
                    self.render()
            else:
                if self.hot:
                    self.hot = False
                    self.render()

    @property
    def text(self):
        return self._text

    @text.setter
    def text(self, value):
        self._text = value
        self.render()

    @property
    def enabled(self):
        return self.active

    @enabled.setter
    def enabled(self, value):
        self.active = value
        self.render()


class Slider(pgt.SpriteObject):
    def __init__(self, game, pos=(0, 0), size=(100, 10), anchor='tl', color="white", bg_color='black',
                 value_range=(0, 100), tcolor=(0, 0, 0), var=None, enabled=True, visible=True, horizontal=True):
        super().__init__(game=game, pos=pos, size=size, anchor=anchor, tcolor=tcolor, visible=visible)
        self._horizontal = horizontal
        self.enabled = enabled
        self.color = color
        self.bg_color = bg_color
        if horizontal:
            self.pval, self.breite = size
        else:
            self.breite, self.pval = size

        self.value_range = value_range
        self.min_value, self.max_value = value_range
        self.dvalue = self.max_value - self.min_value

        self.sliding = False
        self.oldx = None

        default_value = (value_range[0] + value_range[1]) / 2
        if not var: var = pgt.TraceVar(default_value)
        self.var = var
        self.var.trace_add(self.on_change, 'c')

        self.render()
        self.activate_events()

    def value_to_width(self, value):
        value -= self.min_value
        return self.pval / self.dvalue * value

    def width_to_value(self, width):
        value = width * self.dvalue / self.pval
        return value + self.min_value

    def xpos_to_value(self, xpos):
        w = xpos - self.rect.left
        return self.width_to_value(w)

    def on_change(self, tag=None):
        self.value = self.var.value
        self.render()

    def render(self):
        self.image.fill(self.bg_color)
        value = self.var.value
        w = self.value_to_width(value)
        pg.draw.rect(self.image, color=self.color, rect=(0, 0, self.size.w, self.size.h), width=3)
        if self._horizontal:
            pg.draw.rect(self.image, color=self.color, rect=(0, 0, w, self.size.h))
        else:
            pg.draw.rect(self.image, color=self.color, rect=(0, self.size.h-w, self.size.w, self.size.h))


    def handle_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos) and self.enabled:
                self.oldx = None
                self.sliding = True
        elif event.type == pg.MOUSEBUTTONUP and event.button == 1:
            self.sliding = False

    def update(self, dt):
        super().update(dt)
        if self.sliding:
            x = pgt.get_mouse_pos().x if self._horizontal else pgt.get_mouse_pos().y
            if self.oldx is None:
                self.oldx = x
                return
            dx = x - self.oldx if self._horizontal else self.oldx - x
            self.oldx = x
            dval = dx * self.dvalue / self.pval
            v = self.var.value + dval
            if v < self.min_value:
                v = self.min_value
            elif v > self.max_value:
                v = self.max_value
            self.var.value = v








